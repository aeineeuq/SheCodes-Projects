# Plus Resources: Django Project Starter

Starter code for the Plus Django project.
